<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
|----------------------------------------------------------------- -------------------------
| URL del sitio base
|----------------------------------------------------------------- -------------------------
|
| URL a su raíz de CodeIgniter. Por lo general, esta será su URL base,
| CON una barra diagonal:
|
| http://ejemplo.com/
|
| ADVERTENCIA: ¡DEBE establecer este valor!
|
| Si no está configurado, CodeIgniter intentará adivinar el protocolo y la ruta
| su instalación, pero debido a problemas de seguridad, se establecerá el nombre de host
| a $_SERVER['SERVER_ADDR'] si está disponible, o localhost en caso contrario.
| El mecanismo de autodetección existe solo por conveniencia durante
| desarrollo y NO DEBE usarse en producción!
|
| Si necesita permitir múltiples dominios, recuerde que este archivo todavía está
| un script PHP y puede hacerlo fácilmente por su cuenta.
|
*/
$config['base_url'] = 'http://registroitesitarimoro.000webhostapp.com/Attendance/'; //change link

/*
|----------------------------------------------------------------- -------------------------
| Archivo de índice
|----------------------------------------------------------------- -------------------------
|
| Por lo general, este será su archivo index.php, a menos que lo haya renombrado como
| algo más. Si está utilizando mod_rewrite para eliminar la página, configure esto
| variable para que quede en blanco.
|
*/
$config['index_page'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Correo electrónico SMTP
|----------------------------------------------------------------- -------------------------
|
| Complete la configuración SMTP para enviar correo electrónico
|
*/
$config['email_smtp'] = Array(
    'protocol' => 'smtp',
    'smtp_host' => '', // Tu anfitrion
    'smtp_port' => 465,
    'smtp_user' => '', // Tu correo electrónico
    'smtp_pass' => '', // Tu contraseña de correo
    'smtp_crypto' => 'ssl', // ssl or tls
    'crlf' => "\r\n",
    'newline' => "\r\n"
);

/*
|----------------------------------------------------------------- -------------------------
| PROTOCOLO URI
|----------------------------------------------------------------- -------------------------
|
| Este elemento determina qué servidor global se debe usar para recuperar el
| Cadena URI. La configuración predeterminada de 'REQUEST_URI' funciona para la mayoría de los servidores.
| Si sus enlaces no parecen funcionar, pruebe uno de los otros deliciosos sabores:
|
| 'REQUEST_URI'    Uses $_SERVER['REQUEST_URI']
| 'QUERY_STRING'   Uses $_SERVER['QUERY_STRING']
| 'PATH_INFO'      Uses $_SERVER['PATH_INFO']
|
|
| ADVERTENCIA: Si establece esto en 'PATH_INFO', ¡los URI siempre se descodificarán como URL!
*/
$config['uri_protocol'] = 'REQUEST_URI';

/*
|----------------------------------------------------------------- -------------------------
| sufijo de URL
|----------------------------------------------------------------- -------------------------
|
| Esta opción le permite agregar un sufijo a todas las URL generadas por CodeIgniter.
| Para obtener más información, consulte la guía del usuario:
|
| https://codeigniter.com/user_guide/general/urls.html
*/
$config['url_suffix'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Idioma predeterminado
|----------------------------------------------------------------- -------------------------
|
| Esto determina qué conjunto de archivos de idioma se debe utilizar. Asegurarse
| hay una traducción disponible si tiene la intención de usar algo diferente
| que el ingles
|
*/
$config['language'] = 'english';

/*
|----------------------------------------------------------------- -------------------------
| Conjunto de caracteres predeterminado
|----------------------------------------------------------------- -------------------------
|
| Esto determina qué conjunto de caracteres se usa de forma predeterminada en varios métodos
| que requieren que se proporcione un juego de caracteres.
|
| Consulte http://php.net/htmlspecialchars para obtener una lista de juegos de caracteres admitidos.
|
*/
$config['charset'] = 'UTF-8';

/*
|----------------------------------------------------------------- -------------------------
| Habilitar/deshabilitar ganchos del sistema
|----------------------------------------------------------------- -------------------------
|
| Si desea utilizar la función 'ganchos', debe habilitarla
| estableciendo esta variable en TRUE (booleano). Consulte la guía del usuario para obtener más información.
|
*/
$config['enable_hooks'] = TRUE; // hooks

/*
|----------------------------------------------------------------- -------------------------
| Prefijo de extensión de clase
|----------------------------------------------------------------- -------------------------
|
| Este elemento le permite establecer el prefijo de nombre de archivo/nombre de clase al extender
| bibliotecas nativas. Para obtener más información, consulte la guía del usuario:
|
| https://codeigniter.com/user_guide/general/core_classes.html
| https://codeigniter.com/user_guide/general/creating_libraries.html
|
*/
$config['subclass_prefix'] = 'MY_';

/*
|--------------------------------------------------------------------------
| Carga automática del compositor
|--------------------------------------------------------------------------
|

| Habilitar esta configuración le indicará a CodeIgniter que busque un Compositor
| paquete de script de carga automática en application/vendor/autoload.php.
|
|	$config['composer_autoload'] = TRUE;
|
| O si tiene su proveedor/directorio ubicado en otro lugar, puede
| también puede optar por establecer una ruta específica:
|
|	$config['composer_autoload'] = '/path/to/vendor/autoload.php';
|
| Para obtener más información sobre Composer, visite http://getcomposer.org/
|
| Nota: Esto NO deshabilitará ni anulará el código específico de CodeIgniter
|	autoloading (application/config/autoload.php)
*/
$config['composer_autoload'] = 'vendor/autoload.php';

/*
|----------------------------------------------------------------- -------------------------
| Caracteres de URL permitidos
|----------------------------------------------------------------- -------------------------
|
| Esto le permite especificar qué caracteres están permitidos en sus URL.
| Cuando alguien intente enviar una URL con caracteres no permitidos,
| obtener un mensaje de advertencia.
|
| Como medida de seguridad, le recomendamos ENCARECIDAMENTE que restrinja las URL a
| la menor cantidad de caracteres posible. Por defecto solo se permiten estos: a-z 0-9~%.:_-
|
| Déjelo en blanco para permitir todos los caracteres, pero solo si está loco.
|
| El valor configurado es en realidad un grupo de caracteres de expresión regular
| y se ejecutará como: ! preg_match('/^[<permitted_uri_chars>]+$/i
|
| ¡NO CAMBIE ESTO A MENOS QUE ENTIENDA COMPLETAMENTE LAS REPERCUSIONES!
|
*/
$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-';

/*
|----------------------------------------------------------------- -------------------------
| Habilitar cadenas de consulta
|----------------------------------------------------------------- -------------------------
|
| De forma predeterminada, CodeIgniter utiliza URL basadas en segmentos compatibles con los motores de búsqueda:
| example.com/who/what/where/
|
| Opcionalmente, puede habilitar las URL basadas en cadenas de consulta estándar:
| example.com?who=me&what=something&where=here
|
| Options are: TRUE or FALSE (boolean)
|
| Los otros elementos le permiten establecer la cadena de consulta 'palabras' que
| invoca a tus controladores y sus funciones:
| ejemplo.com/index.php?c=controlador&m=función
|
| Tenga en cuenta que algunos de los ayudantes no funcionarán como se esperaba cuando
| esta función está habilitada, ya que CodeIgniter está diseñado principalmente para
| utilice direcciones URL basadas en segmentos.
|
*/
$config['enable_query_strings'] = FALSE;
$config['controller_trigger'] = 'c';
$config['function_trigger'] = 'm';
$config['directory_trigger'] = 'd';

/*
|----------------------------------------------------------------- -------------------------
| Permitir matriz $_GET
|----------------------------------------------------------------- -------------------------
|
| De forma predeterminada, CodeIgniter habilita el acceso a la matriz $_GET. si para algunos
| razón por la que le gustaría deshabilitarlo, establezca 'allow_get_array' en FALSO.
|
| ADVERTENCIA: Esta función está DESAPROBADA y actualmente solo está disponible
| para fines de compatibilidad con versiones anteriores!
|
*/
$config['allow_get_array'] = TRUE;

/*
|--------------------------------------------------------------------------
| Límite de registro de errores
|----------------------------------------------------------------- -------------------------
|
| Puede habilitar el registro de errores estableciendo un umbral superior a cero. Él
| El umbral determina lo que se registra. Las opciones de umbral son:
|
| 0 = Deshabilita el registro, Registro de errores DESACTIVADO
| 1 = Mensajes de error (incluidos los errores de PHP)
| 2 = Mensajes de depuración
| 3 = Mensajes informativos
| 4 = Todos los mensajes
|
| También puede pasar una matriz con niveles de umbral para mostrar tipos de errores individuales
|
| array(2) = Mensajes de depuración, sin mensajes de error
|
| Para un sitio en vivo, generalmente solo habilitará los errores (1) para que se registren de lo contrario
| sus archivos de registro se llenarán muy rápido.
|
Abrir en Google 
*/
$config['log_threshold'] = 0;

/*
|--------------------------------------------------------------------------
| Ruta del directorio de registro de errores
|----------------------------------------------------------------- -------------------------
|
| Deje esto EN BLANCO a menos que desee configurar algo que no sea el predeterminado
| aplicación/registros/directorio. Use una ruta de servidor completa con una barra diagonal final.
|
*/
$config['log_path'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Extensión de archivo de registro
|----------------------------------------------------------------- -------------------------
|
| La extensión de nombre de archivo predeterminada para los archivos de registro. El 'php' predeterminado permite
| proteger los archivos de registro a través de secuencias de comandos básicas, cuando se van a almacenar
| en un directorio de acceso público.
|
| Nota: Si lo deja en blanco, el valor predeterminado será 'php'.
|
*/
$config['log_file_extension'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Permisos de archivo de registro
|----------------------------------------------------------------- -------------------------
|
| Los permisos del sistema de archivos que se aplicarán a los archivos de registro recién creados.
|
| IMPORTANTE: DEBE ser un número entero (sin comillas) y DEBE usar octal
| notación entera (es decir, 0700, 0644, etc.)
*/
$config['log_file_permissions'] = 0644;

/*
|----------------------------------------------------------------- -------------------------
| Formato de fecha para registros
|----------------------------------------------------------------- -------------------------
|
| Cada elemento que se registra tiene una fecha asociada. Puedes usar la fecha de PHP
| códigos para establecer su propio formato de fecha
|

*/
$config['log_date_format'] = 'Y-m-d H:i:s';

/*
|----------------------------------------------------------------- -------------------------
| Ruta del directorio de vistas de error
|----------------------------------------------------------------- -------------------------
|
| Deje esto EN BLANCO a menos que desee configurar algo que no sea el predeterminado
| aplicación/vistas/errores/directorio. Use una ruta de servidor completa con una barra diagonal final.
|
*/
$config['error_views_path'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Ruta del directorio de caché
|----------------------------------------------------------------- -------------------------
|
| Deje esto EN BLANCO a menos que desee configurar algo que no sea el predeterminado
| aplicación/caché/directorio. Use una ruta de servidor completa con una barra diagonal final.
|
*/
$config['cache_path'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Cadena de consulta de inclusión de caché
|----------------------------------------------------------------- -------------------------
|
| Si se debe tener en cuenta la cadena de consulta de URL al generar
| archivos de caché de salida. Las opciones válidas son:
|
| FALSO = Deshabilitado
| VERDADERO = Habilitado, tiene en cuenta todos los parámetros de consulta.
| Tenga en cuenta que esto puede dar lugar a numerosos caché
| archivos generados para la misma página una y otra vez.
| array('q') = Habilitado, pero solo tiene en cuenta la lista especificada
| de parámetros de consulta.
|
*/
$config['cache_query_string'] = FALSE;

/*
|----------------------------------------------------------------- -------------------------
| Clave de encriptación
|----------------------------------------------------------------- -------------------------
|
| Si utiliza la clase de cifrado, debe establecer una clave de cifrado.
| Consulte la guía del usuario para obtener más información.
|
| https://codeigniter.com/user_guide/libraries/encryption.html
|
*/
$config['encryption_key'] = '';

/*
|----------------------------------------------------------------- -------------------------
| Variables de sesión
|----------------------------------------------------------------- -------------------------
|
| 'controlador_sess'
|
| El controlador de almacenamiento a usar: archivos, base de datos, redis, memcached
|
| 'sess_cookie_name'
|
| El nombre de la cookie de sesión debe contener solo [0-9a-z_-] caracteres
|
| 'sess_expiration'
|
| El número de SEGUNDOS que quieres que dure la sesión.
| Establecer en 0 (cero) significa que caduca cuando se cierra el navegador.
|
| 'sess_save_path'
|
| La ubicación para guardar sesiones, depende del controlador.
|
| Para el controlador de 'archivos', es una ruta a un directorio de escritura.
| ADVERTENCIA: ¡Solo se admiten rutas absolutas!
|
| Para el controlador de 'base de datos', es un nombre de tabla.
| Lea el manual para formatear con otros controladores de sesión.
|
| IMPORTANTE: ¡Se le REQUIERE establecer una ruta de guardado válida!
|
| 'sess_match_ip'
|
| Si hacer coincidir la dirección IP del usuario al leer los datos de la sesión.
|
| ADVERTENCIA: si está utilizando el controlador de la base de datos, no olvide actualizar
| la CLAVE PRIMARIA de su tabla de sesión al cambiar esta configuración.
|
| 'sess_time_to_update'
|
| Cuántos segundos entre CI que regenera el ID de sesión.
|
| 'sess_regenerate_destroy'
|
| Ya sea para destruir los datos de sesión asociados con la ID de sesión anterior
| al regenerar automáticamente el ID de sesión. Cuando se establece en FALSO, los datos
| será eliminado más tarde por el recolector de basura.
|
| Otras configuraciones de cookies de sesión se comparten con el resto de la aplicación,
| a excepción de 'cookie_prefix' y 'cookie_httponly', que se ignoran aquí.
|
*/
$config['sess_driver'] = 'files';
$config['sess_cookie_name'] = 'ci_session';
$config['sess_expiration'] = 7200;
$config['sess_save_path'] = NULL;
$config['sess_match_ip'] = FALSE;
$config['sess_time_to_update'] = 300;
$config['sess_regenerate_destroy'] = FALSE;

/*
|--------------------------------------------------------------------------
| Variables relacionadas con las cookies
|----------------------------------------------------------------- -------------------------
|
| 'cookie_prefix' = Establezca un prefijo de nombre de cookie si necesita evitar colisiones
| 'cookie_domain' = Establecer en .your-domain.com para cookies de todo el sitio
| 'cookie_path' = Normalmente será una barra diagonal
| 'cookie_secure' = La cookie solo se establecerá si existe una conexión HTTPS segura.
| 'cookie_httponly' = Solo se podrá acceder a la cookie a través de HTTP(S) (sin javascript)
|
| Nota: estas configuraciones (con la excepción de 'cookie_prefix' y
| 'cookie_httponly') también afectará a las sesiones.
|

*/
$config['cookie_prefix'] = '';
$config['cookie_domain'] = '';
$config['cookie_path'] = '/';
$config['cookie_secure'] = FALSE;
$config['cookie_httponly'] = FALSE;

/*
|----------------------------------------------------------------- -------------------------
| Estandarizar líneas nuevas
|----------------------------------------------------------------- -------------------------
|
| Determina si estandarizar los caracteres de nueva línea en los datos de entrada,
| lo que significa reemplazar \r\n, \r, \n ocurrencias con el valor PHP_EOL.
|
| ADVERTENCIA: Esta función está DESAPROBADA y actualmente solo está disponible
| para fines de compatibilidad con versiones anteriores!
|
*/
$config['standardize_newlines'] = FALSE;

/*
|----------------------------------------------------------------- -------------------------
| Filtrado XSS global
|----------------------------------------------------------------- -------------------------
|
| Determina si el filtro XSS siempre está activo cuando GET, POST o
| Se encuentran datos de COOKIE
|
| ADVERTENCIA: Esta función está DESAPROBADA y actualmente solo está disponible
| para fines de compatibilidad con versiones anteriores!
|
*/
$config['global_xss_filtering'] = FALSE;

/*
|----------------------------------------------------------------- -------------------------
| Falsificación de solicitud entre sitios
|----------------------------------------------------------------- -------------------------
| Permite configurar un token de cookie CSRF. Cuando se establece en TRUE, el token será
| verificado en un formulario enviado. Si está aceptando datos de usuario, es fuertemente
| Se recomienda activar la protección CSRF.
|
| 'csrf_token_name' = El nombre del token
| 'csrf_cookie_name' = El nombre de la cookie
| 'csrf_expire' = El número en segundos que debe caducar el token.
| 'csrf_regenerate' = Regenerar token en cada envío
| 'csrf_exclude_uris' = Conjunto de URI que ignoran las comprobaciones CSRF
*/
$config['csrf_protection'] = FALSE;
$config['csrf_token_name'] = 'csrf_test_name';
$config['csrf_cookie_name'] = 'csrf_cookie_name';
$config['csrf_expire'] = 7200;
$config['csrf_regenerate'] = TRUE;
$config['csrf_exclude_uris'] = array();

/*
|--------------------------------------------------------------------------
| Compresión de salida
|----------------------------------------------------------------- -------------------------
|
| Habilita la compresión de salida Gzip para cargas de página más rápidas. Cuando está habilitado,
| la clase de salida probará si su servidor es compatible con Gzip.
| Sin embargo, incluso si lo hace, no todos los navegadores admiten la compresión.
| así que habilítelo solo si está razonablemente seguro de que sus visitantes pueden manejarlo.
|
| Solo se usa si zlib.output_compression está desactivado en su php.ini.
| No lo use junto con la compresión de salida de nivel httpd.
|
| MUY IMPORTANTE: si obtiene una página en blanco cuando la compresión está habilitada,
| significa que está enviando algo prematuramente a su navegador. Podria
| incluso ser una línea de espacio en blanco al final de uno de sus scripts. Para
| compresión para trabajar, no se puede enviar nada antes de que se llame al búfer de salida
| por la clase de salida. No 'haga eco' de ningún valor con la compresión habilitada.
|
*/
$config['compress_output'] = false; //Gzip

/*
|----------------------------------------------------------------- -------------------------
| Referencia de tiempo maestro
|----------------------------------------------------------------- -------------------------
|
| Las opciones son 'locales' o cualquier zona horaria compatible con PHP. Esta preferencia dice
| el sistema si debe usar la hora local de su servidor como el maestro 'ahora'
| referencia, o convertirlo a la zona horaria configurada. Ver la 'fecha
| página de ayuda de la guía del usuario para obtener información sobre el manejo de fechas.
|
*/
$config['time_reference'] = 'local';

/*
|----------------------------------------------------------------- -------------------------
| Reescribir etiquetas cortas de PHP
|----------------------------------------------------------------- -------------------------
|
| Si su instalación de PHP no tiene habilitado el soporte de etiquetas cortas CI
| puede reescribir las etiquetas sobre la marcha, lo que le permite utilizar esa sintaxis
| en sus archivos de vista. Las opciones son VERDADERO o FALSO (booleano)
|
| Nota: Debe tener habilitado eval() para que esto funcione.
|
*/
$config['rewrite_short_tags'] = FALSE;

/*
|----------------------------------------------------------------- -------------------------
| IP de proxy inverso
|----------------------------------------------------------------- -------------------------
|
| Si su servidor está detrás de un proxy inverso, debe incluir el proxy en la lista blanca
| Direcciones IP desde las que CodeIgniter debe confiar en encabezados como
| HTTP_X_FORWARDED_FOR y HTTP_CLIENT_IP para identificar correctamente
| la dirección IP del visitante.
|
| Puede usar una matriz o una lista separada por comas de direcciones proxy,
| así como especificar subredes completas. Aquí están algunos ejemplos:
|
| Separados por comas: '10.0.1.200,192.168.5.0/24'
| Matriz: matriz('10.0.1.200', '192.168.5.0/24')
*/
$config['proxy_ips'] = '';

/*
|--------------------------------------------------------------------------
| Funciones y estado
|----------------------------------------------------------------- -------------------------
|
| Usuario de roles y usuario de estado
|
*/
$config['roles'] = array('3', '1');
$config['status'] = array('pending', 'approved');
$config['banned_users'] = array('unban', 'ban');

/*
|----------------------------------------------------------------- -------------------------
| Remitente de correo electrónico
|----------------------------------------------------------------- -------------------------
|
| Esto es sobre el remitente del correo electrónico
|
*/
$config['register'] = 'admin@gmail.com';
$config['forgot'] = 'admin@gmail.com';
