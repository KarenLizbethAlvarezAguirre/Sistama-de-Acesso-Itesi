<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
|----------------------------------------------------------------- -------------------------
| Mostrar seguimiento de depuración
|----------------------------------------------------------------- -------------------------
|
| Si se establece en VERDADERO, se mostrará un seguimiento junto con los errores de php. Si
| error_reporting está deshabilitado, el backtrace no se mostrará, independientemente
| de esta configuración
|
*/
defined('SHOW_DEBUG_BACKTRACE') or define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|----------------------------------------------------------------- -------------------------
| Modos de archivo y directorio
|----------------------------------------------------------------- -------------------------
|
| Estas preferencias se usan al verificar y configurar modos cuando se trabaja
| con el sistema de archivos. Los valores predeterminados están bien en servidores con
| seguridad, pero es posible que desee (o incluso necesite) cambiar los valores en
| ciertos entornos (Apache ejecutando un proceso separado para cada
| usuario, PHP bajo CGI con Apache suEXEC, etc.). Los valores octales deben
| siempre se utilizará para configurar el modo correctamente.
|
*/
defined('FILE_READ_MODE') or define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') or define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE') or define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE') or define('DIR_WRITE_MODE', 0755);

/*
|----------------------------------------------------------------- -------------------------
| Modos de transmisión de archivos
|----------------------------------------------------------------- -------------------------
|
| Estos modos se usan cuando se trabaja con fopen()/popen()
|
*/
defined('FOPEN_READ') or define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE') or define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE') or define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE') or define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE') or define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE') or define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT') or define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT') or define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|----------------------------------------------------------------- -------------------------
| Códigos de estado de salida
|----------------------------------------------------------------- -------------------------
|
| Se usa para indicar las condiciones bajo las cuales el script está saliendo ().
| Si bien no existe un estándar universal para los códigos de error, hay algunos
| convenciones amplias. A continuación se mencionan tres convenciones de este tipo, por
| aquellos que deseen hacer uso de ellos. Los valores predeterminados de CodeIgniter eran
| elegido por la menor superposición con estas convenciones, mientras que todavía
| dejando espacio para que otros se definan en futuras versiones y usuarios
| aplicaciones
|
| Las tres convenciones principales utilizadas para determinar los códigos de estado de salida
| son como sigue:
|
| Biblioteca estándar de C/C++ (stdlibc):
| http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
| (Este enlace también contiene otras convenciones específicas de GNU)
| Salidas del sistema BSD.h:
| http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sys sale
| Secuencias de comandos bash:
| http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS') or define('EXIT_SUCCESS', 0); // sin errores
defined('EXIT_ERROR') or define('EXIT_ERROR', 1); // error generico
defined('EXIT_CONFIG') or define('EXIT_CONFIG', 3); // error de configuración
defined('EXIT_UNKNOWN_FILE') or define('EXIT_UNKNOWN_FILE', 4); //archivo no encontrado
defined('EXIT_UNKNOWN_CLASS') or define('EXIT_UNKNOWN_CLASS', 5); // clase desconocida
defined('EXIT_UNKNOWN_METHOD') or define('EXIT_UNKNOWN_METHOD', 6); //Miembro de la clase desconocido
defined('EXIT_USER_INPUT') or define('EXIT_USER_INPUT', 7); // entrada de usuario inválida
defined('EXIT_DATABASE') or define('EXIT_DATABASE', 8); // Error de la base de datos
defined('EXIT__AUTO_MIN') or define('EXIT__AUTO_MIN', 9); // código de error asignado automáticamente más bajo
defined('EXIT__AUTO_MAX') or define('EXIT__AUTO_MAX', 125); //código de error asignado automáticamente más alto
