<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------- -----------------
| AJUSTES DE CONECTIVIDAD DE LA BASE DE DATOS
| -------------------------------------------------- -----------------
| Este archivo contendrá la configuración necesaria para acceder a su base de datos.
|
| Para obtener instrucciones completas, consulte la 'Conexión de la base de datos'
| página de la Guía del usuario.
|
| -------------------------------------------------- -----------------
| EXPLICACIÓN DE VARIABLES
| -------------------------------------------------- -----------------
|
| ['dsn'] La cadena DSN completa describe una conexión a la base de datos.
| ['hostname'] El nombre de host de su servidor de base de datos.
| ['username'] El nombre de usuario utilizado para conectarse a la base de datos
| ['contraseña'] La contraseña utilizada para conectarse a la base de datos
| ['database'] El nombre de la base de datos a la que desea conectarse
| ['dbdriver'] El controlador de la base de datos. por ejemplo: mysqli.
| Actualmente soportado:
| cubrid, ibase, mssql, mysql, mysqli, oci8,
| odbc, pdo, postgre, sqlite, sqlite3, sqlsrv
| ['dbprefix'] Puede agregar un prefijo opcional, que se agregará
| al nombre de la tabla cuando se usa la clase Query Builder
| ['pconnect'] VERDADERO/FALSO: si usar una conexión persistente
| ['db_debug'] VERDADERO/FALSO: si se deben mostrar los errores de la base de datos.
| ['cache_on'] VERDADERO/FALSO: activa/desactiva el almacenamiento en caché de consultas
| ['cachedir'] La ruta a la carpeta donde se deben almacenar los archivos de caché
| ['char_set'] El conjunto de caracteres utilizado en la comunicación con la base de datos
| ['dbcollat'] La intercalación de caracteres utilizada en la comunicación con la base de datos
| NOTA: Para las bases de datos MySQL y MySQLi, esta configuración solo se usa
| como respaldo si su servidor ejecuta PHP < 5.2.3 o MySQL < 5.0.7
| (y en las consultas de creación de tablas realizadas con DB Forge).
| Hay una incompatibilidad en PHP con mysql_real_escape_string() que
| puede hacer que su sitio sea vulnerable a la inyección SQL si está utilizando un
| conjunto de caracteres de varios bytes y ejecutan versiones inferiores a estas.
| Los sitios que utilizan el conjunto de caracteres y la intercalación de la base de datos Latin-1 o UTF-8 no se ven afectados.
| ['swap_pre'] Un prefijo de tabla predeterminado que debe intercambiarse con el prefijo db
| ['encrypt'] Si usar o no una conexión cifrada.
|
| Los controladores 'mysql' (obsoleto), 'sqlsrv' y 'pdo/sqlsrv' aceptan VERDADERO/FALSO
| Los controladores 'mysqli' y 'pdo/mysql' aceptan una matriz con las siguientes opciones:
|
| 'ssl_key' - Ruta al archivo de clave privada
| 'ssl_cert': ruta al archivo de certificado de clave pública
| 'ssl_ca': ruta al archivo de la autoridad de certificación
| 'ssl_capath': ruta a un directorio que contiene certificados de CA confiables en formato PEM
| 'ssl_cipher': lista de cifrados *permitidos* que se utilizarán para el cifrado, separados por dos puntos (':')
| 'ssl_verify' - VERDADERO/FALSO; Si verifica el certificado del servidor o no (solo 'mysqli')
|
| ['compress'] Uso o no de la compresión del cliente (solo MySQL)
| ['stricton'] VERDADERO/FALSO: fuerza las conexiones de 'Modo estricto'
| - bueno para garantizar SQL estricto durante el desarrollo
| ['ssl_options'] Se usa para establecer varias opciones de SSL que se pueden usar al realizar conexiones SSL.
| Matriz ['failover']: una matriz con 0 o más datos para las conexiones si la principal falla.
| ['save_queries'] VERDADERO/FALSO: si "guardar" todas las consultas ejecutadas.
| NOTA: Deshabilitar esto también deshabilitará efectivamente ambos
| $this->db->last_query() y creación de perfiles de consultas DB.
| Cuando ejecuta una consulta, con esta configuración establecida en VERDADERO (predeterminado),
| CodeIgniter almacenará la instrucción SQL con fines de depuración.
| Sin embargo, esto puede provocar un uso elevado de la memoria, especialmente si ejecuta
| muchas consultas SQL ... deshabilite esto para evitar ese problema.
|
| La variable $active_group le permite elegir qué grupo de conexión
| activar. De forma predeterminada, solo hay un grupo (el grupo 'predeterminado').
|
| Las variables $query_builder le permiten determinar si cargar o no
| la clase del generador de consultas.
*/
$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
    'dsn' => '',
    'hostname' => 'localhost',
    'username' => 'id18210055_alvarez',
    'password' => 'YO8|!65qT{8SH0@n',
    'database' => 'id18210055_registroitesitarimoro',
    'dbdriver' => 'mysqli',
    'dbprefix' => '',
    'pconnect' => FALSE,
    'db_debug' => (ENVIRONMENT !== 'production'),
    'cache_on' => FALSE,
    'cachedir' => '',
    'char_set' => 'utf8',
    'dbcollat' => 'utf8_general_ci',
    'swap_pre' => '',
    'encrypt' => FALSE,
    'compress' => FALSE,
    'stricton' => FALSE,
    'failover' => array(),
    'save_queries' => TRUE
);
