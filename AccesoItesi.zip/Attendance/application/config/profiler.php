<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------- -----------------------
| Secciones del generador de perfiles
| -------------------------------------------------- -----------------------
| Este archivo le permite determinar si varias secciones de Profiler
| los datos se muestran cuando el generador de perfiles está habilitado.
| Consulte la guía del usuario para obtener información:
|
| https://codeigniter.com/user_guide/general/profiling.html
|
*/
