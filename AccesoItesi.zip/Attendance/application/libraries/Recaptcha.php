<?php

/**
 * CodeIgniter NO Captcha ReCAPTCHA a.k.a biblioteca reCAPTCHA Versión 2.0
 *
 * Esta biblioteca se basa en la biblioteca oficial reCAPTCHA para PHP
 * https://github.com/google/ReCAPTCHA
 *
 */
defined('BASEPATH') or exit('No direct script access allowed');

class ReCaptcha
{

    public $secret = "6Lca7mcfAAAAACnchFUxfgowBPY4Vc7HvdtPp7cV"; //Your SiteKey
    private $dataSitekey = "6Lca7mcfAAAAAGAsKOI47On7AV3N6WnLxIfSCfiT";
    private $lang = "en"; //Secret

    public function render()
    {
        $return = '<div class="g-recaptcha" data-sitekey="' . $this->dataSitekey . '"></div>
            <script src="https://www.google.com/recaptcha/api.js?hl=' . $this->lang . '" async defer></script>';
        return $return;
    }

}
