<div class="col-lg-4 col-lg-offset-4">
    <h2>Editar Usuario</h2>
    <h5>Hola <span><?php echo $first_name; ?></span>, <br>Porfavor llenar los campos correspondientes.</h5>
    <hr>
    <?php $fattr = array('class' => 'form-signin');
    echo form_open(site_url() . 'user/edit/' . $id, $fattr); ?>

    <?php
    foreach ($groups as $row) {
        $id = $row->id;
        $first_name = $row->first_name;
        $last_name = $row->last_name;
        $no_control=$row->no_control;
        $carrera=$row->carrera;
        $semestre=$row->semestre;
        $email = $row->email;
        $role = $row->role;
    }
    ?>
    <div class="form-group">
        <?php echo form_input(array('name' => 'firstname', 'id' => 'firstname', 'placeholder' => 'Nombre', 'class' => 'form-control', 'value' => $first_name)); ?>
        <?php echo form_error('firstname'); ?>
    </div>
    <div class="form-group">
        <?php echo form_input(array('name' => 'lastname', 'id' => 'lastname', 'placeholder' => 'Apellido', 'class' => 'form-control', 'value' => $last_name)); ?>
        <?php echo form_error('lastname'); ?>
   <div class="form-group">
        <?php echo form_input(array('name' => 'no_control', 'id' => 'no_control', 'placeholder' => 'No. de control', 'class' => 'form-control', 'value' => $no_control)); ?>
        <?php echo form_error('no_control'); ?>
    </div>
    <div class="form-group">
        <?php
        $dd_listc = array(
            'Sistemas Computacionales' => 'Sistemas Computacionales',
            'Indusrial' => 'Industrial',
            'Sistemas Automotrices' => 'Sistemas Automotrices',
            'Gestion Empresarial' => 'Gestion Empresarial',
        );
        $dd_namec = "carrera";
        echo form_dropdown($dd_namec, $dd_listc, set_value($dd_namec, $carrera), 'class = "form-control" id="carrera"');
        ?>
    </div>
    <div class="form-group">
        <?php echo form_input(array('name' => 'email', 'id' => 'email', 'placeholder' => 'Correo', 'class' => 'form-control', 'value' => $email)); ?>
        <?php echo form_error('email'); ?>
    </div>
    <div class="form-group">
        <?php
        $dd_lists = array(
            '1' => '1°',
            '2' => '2°',
            '3' => '3°',
            '4' => '4°',
            '5' => '5°',
            '6' => '6°',
            '7' => '7°',
            '8' => '8°',
            '9' => '9°',
            'NA' => 'NA',
        );
        $dd_names = "semestre";
        echo form_dropdown($dd_names, $dd_lists, set_value($dd_names, $semestre), 'class = "form-control" id="semestre"');
        ?>
    </div>
 
    <div class="form-group">
        <?php
        $dd_list = array(
            '1' => 'Administrador',
            '2' => 'Docente',
            '3' => 'Alumno',
        );
        $dd_name = "role";
        echo form_dropdown($dd_name, $dd_list, set_value($dd_name, $role), 'class = "form-control" id="role"');
        ?>
    </div>
    <div class="form-group">
        <?php echo form_password(array('name' => 'password', 'id' => 'password', 'placeholder' => 'Contraseña', 'class' => 'form-control', 'value' => set_value('password'))); ?>
        <?php echo form_error('password') ?>
    </div>
    <div class="form-group">
        <?php echo form_password(array('name' => 'passconf', 'id' => 'passconf', 'placeholder' => 'Confirmar contraseña', 'class' => 'form-control', 'value' => set_value('passconf'))); ?>
        <?php echo form_error('passconf') ?>
    </div>
    <?php echo form_submit(array('value' => 'Guardar', 'class' => 'btn btn-lg btn-primary btn-block')); ?>
    <a href="<?php echo site_url() . 'user/'; ?>">
        <button type="button" class="btn btn-default btn-lg btn-block">Cancelar</button>
    </a>
    <?php echo form_close(); ?>
</div>
